%% Physical Constants
% global c eps0
c = 299792458;
eps0 = 8.854187817e-12;
A = 96100e-18;