clear all;
close all;

%% loading
addpath('../Scattering files_Megha Khokhar');
PhysConst;
load('Electric field and refractive index data.mat');
[Cp,CT,Cm,CQe,CQm,Csum] = Figure2b_Scattering(x,y,z,f,Ex,Ey,Ez,n_x,n_y,n_z);
[arg_px,arg_py,arg_pz,arg_ikTx,arg_ikTy,arg_ikTz,arg_pTx,arg_pTy,arg_pTz,arg_my,arg_Qexz,arg_Qmyz] = FigureS2a_Scatteringphase(x,y,z,f,Ex,Ey,Ez,n_x,n_y,n_z);

%% plot
lbdp = c./f*1e9;
result = [Cp,CT,Cm,CQe,CQm,Csum];
result_phase = [arg_px,arg_ikTx,arg_pTx,arg_my,arg_Qexz,arg_Qmyz];


fig1 = figure();
plot(lbdp,result(:,1:5)*1e18,'o-'); hold on;
plot(lbdp,result(:,6)*1e18,'k--');  
legend('C^{p}_{\rm sca}', 'C^{T}_{\rm sca}', 'C^{m}_{\rm sca}', ...
       'C^{Q^e}_{\rm sca}','C^{Q^m}_{\rm sca}', ...
       'C^{Total}_{\rm sca}','FontSize', 12);
title('Scattering spectra of a silicon nanodisk', 'FontSize',12);
xlabel('Wavelength (nm)', 'FontSize',12);
ylabel('Scattering cross section (nm^2)', 'FontSize',12);
xlim([min(lbdp),max(lbdp)]);

fig2 = figure();
plot(lbdp,result_phase(:,1:2)); hold on;
legend('p_x','-ikT_x','FontSize',12);
title('Phase of electric and toroidal dipole moments of a silicon nanodisk', 'FontSize',12);
xlabel('Wavelength (nm)', 'FontSize',12);
ylabel('Phase (rad)', 'FontSize',12);
xlim([min(lbdp),max(lbdp)]);

%% save
print(fig1, mfilename, '-dpng');
print(fig2, [mfilename,'_phase'], '-dpng');

out1 = [lbdp,result];
outfilename = [mfilename,'.csv'];
csvwrite(outfilename,out1);

out2 = [lbdp,result_phase];
outfilename = [mfilename,'_phase.csv'];
csvwrite(outfilename,out2);