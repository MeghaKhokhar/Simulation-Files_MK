function [arg_px,arg_py,arg_pz,arg_ikTx,arg_ikTy,arg_ikTz,arg_pTx,arg_pTy,arg_pTz,arg_my,arg_Qexz,arg_Qmyz] = FigureS2a_Scatteringphase(x,y,z,f,Ex,Ey,Ez,n_x,n_y,n_z)
%Script file for calculating the decomposed multipoles_ Figure 2b_Megha Khokhar
% Input properties
% x,y,z: 1D arrays which defines position vector r=(x,y,z) toward each
%        meshgrid point to be calculated. Units are [m].
% Ex,Ey,Ez: Complex electric fields E(r,f)=E(x,y,z,f)=(Ex,Ey,Ez).
%           Exported data from EM simulation software can be used.
% n_x,n_y,n_z: Refractive indices at the corresponding meshgrid.
% 
% Output properties
% Cp,Cm,CQe,CQm: Scattering cross section from each of multipole moment.
% Cp: electric dipole
% CT: toroidal dipole
% Cm: magnetic dipole
% CQe: electric quadrupole
% CQm: magnetic quadrupole
%
% Adapted from reference:
% MENP: An Open-Source MATLAB Implementation of Multipole Expansion for Applications in Nanophotonics

    %% prepare
    addpath('../Scattering files_Megha Khokhar');
    PhysConst;
    load('Electric field and refractive index data.mat');
    [x4d,y4d,z4d,f4d] = ndgrid(x,y,z,f);
    
    omega = 2*pi*f;
    k = omega/c;

    %% get current density
    [Jx,Jy,Jz] = E2J(Ex,Ey,Ez,n_x,n_y,n_z,f4d);

    %% calculate often used values
    % scalar product
    rJ = x4d.*Jx + y4d.*Jy + z4d.*Jz;  % product r,J(r)
    rr = x4d.*x4d + y4d.*y4d + z4d.*z4d;  % product r,r
    
    % cross product r x J = (ry*Jz-rz*Jy, rz*Jx-rx*Jz, rx*Jy-ry*Jx)
    rxJx = (y4d.*Jz - z4d.*Jy);
    rxJy = (z4d.*Jx - x4d.*Jz);
    rxJz = (x4d.*Jy - y4d.*Jx);
    
    %% calculate multipole moments and cross sections
    % calculate electric dipole p,
    px = -1./(1i*omega).*(trapz4Dto1D(Jx,x,y,z));
    py = -1./(1i*omega).*(trapz4Dto1D(Jy,x,y,z));
    pz = -1./(1i*omega).*(trapz4Dto1D(Jz,x,y,z));
    arg_px = angle(px);
    arg_py = angle(py);
    arg_pz = angle(pz);
%     arg_px = atan(real(px)./imag(px));
%     arg_py = atan(real(py)./imag(py));
%     arg_pz = atan(real(pz)./imag(pz));
    
    % calculate toroidal dipole T,
    dTx = rJ.*x4d-2*rr.*Jx;
    dTy = rJ.*y4d-2*rr.*Jy;
    dTz = rJ.*z4d-2*rr.*Jz;
    Tx = 1/(10*c)*trapz4Dto1D(dTx,x,y,z);
    Ty = 1/(10*c)*trapz4Dto1D(dTy,x,y,z);
    Tz = 1/(10*c)*trapz4Dto1D(dTz,x,y,z);
    ikTx = -1i*k.*Tx;
    ikTy = -1i*k.*Ty;
    ikTz = -1i*k.*Tz;
    arg_ikTx = angle(ikTx);
    arg_ikTy = angle(ikTy);
    arg_ikTz = angle(ikTz);
%     arg_ikTx = atan(real(ikTx)./imag(ikTx));
%     arg_ikTy = atan(real(ikTy)./imag(ikTy));
%     arg_ikTz = atan(real(ikTz)./imag(ikTz));

    % calculate net electric dipole moment (p+ikT) pT,
    pTx = px+1i*k.*Tx;
    pTy = py+1i*k.*Ty;
    pTz = pz+1i*k.*Tz;
    arg_pTx = angle(pTx);
    arg_pTy = angle(pTy);
    arg_pTz = angle(pTz);
    
     % calculate magnetic dipole m,
    % dm:=r x J(r)
    dmy = rxJy;
    my = 1/2*trapz4Dto1D(dmy,x,y,z);
    arg_my = angle(my);
    
     % calculate electric quadrupole Qe
    dQe1xz = 3*(z4d.*Jx+x4d.*Jz);
    dQe2xz = 4*x4d.*z4d.*rJ - 5*rr.*(x4d.*Jz+z4d.*Jx);
    Qexz = -1./(1i*omega).*(trapz4Dto1D(dQe1xz,x,y,z)+ ...
           k.^2/14.*trapz4Dto1D(dQe2xz,x,y,z));
    arg_Qexz = angle(Qexz);

   % calculate magnetic quadrupole Qm
    dQmyz = y4d.*rxJz+z4d.*rxJy;
    Qmyz = trapz4Dto1D(dQmyz,x,y,z);
    arg_Qmyz = angle(Qmyz);

  
    
end